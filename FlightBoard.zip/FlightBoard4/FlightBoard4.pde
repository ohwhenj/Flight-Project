// Flight Board

import java.util.ArrayList;

ArrayList<String[]> flights = new ArrayList<String[]>();

boolean showDep      = true;
String  query        = "";
boolean searchActive = false;
int     scrollRow    = 0;
final int ROWS = 14;

final int W = 1280, H = 760;

final int BTN_Y = 30, BTN_H = 50, BTN_W = 200;
int depBtnX, arrBtnX;

final int SY = 100, SH = 40;
final int TX = 40, TY = 160, TW = W - 80;
final int RH = 38, HH = 38;

int[] COL;

final color BG     = color(0);
final color WHITE  = color(255);
final color GREY   = color(150);
final color DIM    = color(70);
final color ROWALT = color(18);
final color SEP    = color(50);
final color GREEN  = color(0, 210, 85);
final color ORANGE = color(255, 138, 0);
final color RED    = color(255, 55, 55);

PFont mono;

void setup() {
  size(1280, 760);
  mono = createFont("Courier New", 16, true);
  textFont(mono);

  depBtnX = W/2 - BTN_W - 8;
  arrBtnX = W/2 + 8;

  COL = new int[]{ TX+8, TX+130, TX+240, TX+350, TX+620, TX+760, TX+900 };

  loadCSV();
}

String[] parseCSVLine(String line) {
  ArrayList<String> fields = new ArrayList<String>();
  boolean inQ = false;
  StringBuilder sb = new StringBuilder();
  for (int i = 0; i < line.length(); i++) {
    char ch = line.charAt(i);
    if (ch == '"')              { inQ = !inQ; }
    else if (ch == ',' && !inQ) { fields.add(sb.toString().trim()); sb = new StringBuilder(); }
    else                        { sb.append(ch); }
  }
  fields.add(sb.toString().trim());
  return fields.toArray(new String[0]);
}

void loadCSV() {
  String[] lines = loadStrings("flights2k.csv");
  if (lines == null || lines.length < 2) return;
  for (int i = 1; i < lines.length; i++) {
    String line = lines[i].trim();
    if (line.isEmpty()) continue;
    String[] c = parseCSVLine(line);
    if (c.length < 16) continue;
    int cancelled = 0;
    try { cancelled = int(trim(c[15])); } catch(Exception e) {}
    flights.add(new String[]{
      trim(c[1]) + trim(c[2]),
      trim(c[3]), city(trim(c[4])),
      trim(c[7]), city(trim(c[8])),
      fmt(trim(c[11])), fmt(trim(c[12])),
      fmt(trim(c[13])), fmt(trim(c[14])),
      st(trim(c[12]), trim(c[11]), cancelled),
      st(trim(c[14]), trim(c[13]), cancelled)
    });
  }
}

String city(String s) {
  int i = s.indexOf(','); return i > 0 ? s.substring(0, i).trim() : s;
}
String fmt(String raw) {
  if (raw == null || raw.isEmpty()) return "";
  try { int t = int(raw); return nf(t/100,2) + ":" + nf(t%100,2); }
  catch(Exception e) { return ""; }
}
String st(String actual, String sched, int cancelled) {
  if (cancelled == 1) return "CANCELLED";
  if (actual == null || actual.isEmpty()) return "---";
  try {
    int diff = int(actual) - int(sched);
    if (diff < -500) diff += 2400;
    if (diff >  500) diff -= 2400;
    return diff > 15 ? "DELAYED" : "ON TIME";
  } catch(Exception e) { return "---"; }
}

ArrayList<String[]> filtered() {
  String q = query.toLowerCase().trim();
  ArrayList<String[]> out = new ArrayList<String[]>();
  for (String[] f : flights) {
    if (q.isEmpty() ||
        f[0].toLowerCase().contains(q) ||
        f[1].toLowerCase().contains(q) ||
        f[2].toLowerCase().contains(q) ||
        f[3].toLowerCase().contains(q) ||
        f[4].toLowerCase().contains(q))
      out.add(f);
  }
  final boolean dep = showDep;
  out.sort((a, b) -> (dep ? a[5] : a[7]).compareTo(dep ? b[5] : b[7]));
  return out;
}

void draw() {
  background(BG);
  ArrayList<String[]> data = filtered();
  drawToggle();
  drawSearch();
  drawTable(data);
  drawArrows(data.size());
}

void drawToggle() {
  fill(showDep ? WHITE : BG); stroke(WHITE); strokeWeight(2);
  rect(depBtnX, BTN_Y, BTN_W, BTN_H);
  fill(showDep ? BG : WHITE); noStroke();
  textSize(16); textAlign(CENTER, CENTER);
  text("DEPARTURES", depBtnX + BTN_W/2, BTN_Y + BTN_H/2);

  fill(!showDep ? WHITE : BG); stroke(WHITE); strokeWeight(2);
  rect(arrBtnX, BTN_Y, BTN_W, BTN_H);
  fill(!showDep ? BG : WHITE); noStroke();
  text("ARRIVALS", arrBtnX + BTN_W/2, BTN_Y + BTN_H/2);
}

void drawSearch() {
  stroke(WHITE); strokeWeight(2); fill(BG);
  rect(TX, SY, TW, SH);

  noStroke(); fill(DIM); textSize(13); textAlign(LEFT, CENTER);
  text("SEARCH:", TX + 12, SY + SH/2);

  
  fill(WHITE); textSize(16);
  text(query, TX + 90, SY + SH/2);
}

void drawTable(ArrayList<String[]> data) {
  fill(WHITE); noStroke();
  rect(TX, TY, TW, HH);

  String fromH = showDep ? "FROM" : "TO";
  String toH   = showDep ? "TO"   : "FROM";
  String[] hdrs = { "FLIGHT", fromH, toH, "CITY", "SCHEDULED", "ACTUAL", "STATUS" };

  fill(BG); textSize(13); textAlign(LEFT, CENTER);
  for (int i = 0; i < hdrs.length; i++)
    text(hdrs[i], COL[i], TY + HH/2);

  int start = scrollRow;
  int end   = min(start + ROWS, data.size());

  for (int i = start; i < end; i++) {
    String[] f = data.get(i);
    int ry = TY + HH + (i - start) * RH;

    if (i % 2 == 0) { fill(ROWALT); noStroke(); rect(TX, ry, TW, RH); }

    stroke(SEP); strokeWeight(1);
    line(TX, ry + RH - 1, TX + TW, ry + RH - 1);

    int cy = ry + RH/2;
    noStroke(); textAlign(LEFT, CENTER);

    String fromCode = showDep ? f[1] : f[3];
    String toCode   = showDep ? f[3] : f[1];
    String toCity   = showDep ? f[4] : f[2];
    String sched    = showDep ? f[5] : f[7];
    String actual   = showDep ? f[6] : f[8];
    String status   = showDep ? f[9] : f[10];

    fill(WHITE);  textSize(16); text(f[0],     COL[0], cy);
    fill(GREY);   textSize(16); text(fromCode,  COL[1], cy);
    fill(WHITE);  textSize(16); text(toCode,    COL[2], cy);
    fill(GREY);   textSize(14); text(clip(toCity, 22), COL[3], cy);
    fill(WHITE);  textSize(16); text(sched.isEmpty() ? "--:--" : sched, COL[4], cy);
    fill(actual.isEmpty() ? DIM : WHITE);
    textSize(16); text(actual.isEmpty() ? "--:--" : actual, COL[5], cy);
    drawStatus(status, COL[6], cy);
  }

  stroke(WHITE); strokeWeight(2); noFill();
  rect(TX, TY, TW, HH + ROWS * RH);

  if (data.isEmpty()) {
    fill(WHITE); textSize(18); textAlign(CENTER, CENTER);
    text("NO FLIGHTS FOUND", TX + TW/2, TY + HH + ROWS*RH/2);
  }
}

void drawStatus(String s, int x, int cy) {
  textSize(14); textAlign(LEFT, CENTER); noStroke();
  if      (s.equals("ON TIME"))    fill(GREEN);
  else if (s.equals("DELAYED"))    fill(ORANGE);
  else if (s.equals("CANCELLED"))  fill(RED);
  else                             fill(DIM);
  text(s, x, cy);
}

void drawArrows(int total) {
  int bot = TY + HH + ROWS * RH + 16;
  textSize(22); textAlign(CENTER, CENTER);
  fill(scrollRow > 0 ? WHITE : DIM); noStroke();
  text("▲", W - 40, bot);
  fill(scrollRow + ROWS < total ? WHITE : DIM);
  text("▼", W - 40, bot + 28);
}

String clip(String s, int n) {
  return s.length() > n ? s.substring(0, n-1) + "." : s;
}

void mousePressed() {
  if (mouseY >= BTN_Y && mouseY <= BTN_Y + BTN_H) {
    if (mouseX >= depBtnX && mouseX <= depBtnX + BTN_W) { showDep = true;  scrollRow = 0; }
    else if (mouseX >= arrBtnX && mouseX <= arrBtnX + BTN_W) { showDep = false; scrollRow = 0; }
  }
  searchActive = (mouseX >= TX && mouseX <= TX + TW &&
                  mouseY >= SY && mouseY <= SY + SH);
  int bot = TY + HH + ROWS * RH + 16;
  ArrayList<String[]> d = filtered();
  if (mouseX >= W - 70) {
    if (mouseY < bot + 14 && scrollRow > 0)
      scrollRow = max(0, scrollRow - ROWS);
    else if (mouseY >= bot + 14 && scrollRow + ROWS < d.size())
      scrollRow = min(max(0, d.size() - ROWS), scrollRow + ROWS);
  }
}

void mouseWheel(MouseEvent e) {
  ArrayList<String[]> d = filtered();
  scrollRow += e.getCount() > 0 ? 1 : -1;
  scrollRow  = constrain(scrollRow, 0, max(0, d.size() - ROWS));
}

void keyPressed() {
  if (!searchActive) return;
  if (key == ESC)                         { query = ""; key = 0; scrollRow = 0; }
  else if (key == BACKSPACE)              { if (query.length() > 0) query = query.substring(0, query.length()-1); scrollRow = 0; }
  else if (key == ENTER || key == RETURN) { searchActive = false; }
  else if (key >= 32 && key < 127 && query.length() < 30) { query += key; scrollRow = 0; }
}
