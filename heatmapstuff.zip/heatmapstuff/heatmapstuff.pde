PImage bg;
int y;
ArrayList<AirportNode> airports;
ArrayList<Flight> flights;
Table table;

void setup()
{
  size (900, 600);
  bg = loadImage("USMap.jpg");
  bg.resize(width, height);
  
  flights = new ArrayList<Flight>();
  loadData();
  setupAirports();
  processFlights();
}


void draw()
{
  background(bg);
  
    for (AirportNode a : airports) 
   {
    a.display();
  }
}

void loadData() {
  table = loadTable("flights2k.csv", "header");

  for (TableRow row : table.rows()) {
    flights.add(new Flight(row));
  }
}

void setupAirports()
{
  airports = new ArrayList<AirportNode>();
  
airports.add(new AirportNode("JFK", 810, 180));
airports.add(new AirportNode("LAX", 170, 350));
airports.add(new AirportNode("ORD", 600, 230));
airports.add(new AirportNode("ABQ", 100, 100));




}

  AirportNode findAirport(String code) {
  for (AirportNode a : airports) {
    if (a.code.equals(code)) {
      return a;
    }
  }
  return null;
}

void processFlights() {
  for (Flight f : flights) {
    AirportNode originNode = findAirport(f.getOrigin());
    AirportNode destNode = findAirport(f.getDest());

    if (originNode != null) {
      originNode.addDeparture();
    }

    if (destNode != null) {
      destNode.addArrival();
    }
  }
}
