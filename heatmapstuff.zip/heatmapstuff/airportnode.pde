class AirportNode
{
  String code;
  float x;
  float y;
  int departures;
  int arrivals;
  
  AirportNode(String code, float x, float y)
  {
    this.code = code;
    this.x = x;
    this.y = y;
    departures = 0;
    arrivals = 0;
    
  }
  
  void addDeparture()
  {
    departures++;
  }
  
  void addArrival()
  {
    arrivals++;
  }
  
  int getTotalTraffic()
  {
    return departures + arrivals;
  }
  
  void display() 
  {
    int traffic = getTotalTraffic();
    
    float amt = map(traffic,0,250,255,0);
    
    fill(255,amt,amt);
    ellipse(x,y,15,15);
    
    fill(255,0,0);
    text(code + ": " + traffic, x + 20, y);
    println(code + " " + traffic);
  }
  
  ////int getMaxTraffic()
  //{
  //  int maxTraffic = 0;
    
  //  for (AirportNode a : airports)
  //  {
      
  //  }
    
  //}
  
  
}
