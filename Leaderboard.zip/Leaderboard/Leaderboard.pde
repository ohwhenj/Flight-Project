// Flight Delay Leaderboard — reads from flights2k.csv
// Place flights2k.csv in your sketch's /data folder
// Press D for delays, C for cancellations

Table table;

String[] airports;
String[] cities;
float[]  vals;
String   mode      = "delay";
int      hoveredRow = -1;
int      SHOW_ROWS  = 10;

void setup() {
  size(600, 420);
  textFont(createFont("Courier New", 14));
  loadData();
}

void loadData() {
  table = loadTable("flights2k.csv", "header");

  // --- Step 1: figure out which airports exist ---
  // Use a temporary parallel structure to accumulate per-airport stats
  StringList codes     = new StringList();
  StringList cityNames = new StringList();
  FloatList  totalDelay  = new FloatList();
  IntList    flightCount = new IntList();
  IntList    cancelCount = new IntList();
  IntList    totalCount  = new IntList();

  for (TableRow row : table.rows()) {
    String code     = row.getString("ORIGIN");
    String city     = row.getString("ORIGIN_CITY_NAME");
    int    cancelled = row.getInt("CANCELLED");
    float  crsTime  = row.getFloat("CRS_DEP_TIME");
    float  depTime  = row.getFloat("DEP_TIME");

    // Find or create this airport's index
    int idx = codes.index(code);
    if (idx == -1) {
      codes.append(code);
      cityNames.append(city);
      totalDelay.append(0);
      flightCount.append(0);
      cancelCount.append(0);
      totalCount.append(0);
      idx = codes.size() - 1;
    }

    // Always count toward total (for cancel rate)
    totalCount.set(idx, totalCount.get(idx) + 1);

    if (cancelled == 1) {
      cancelCount.set(idx, cancelCount.get(idx) + 1);
    } else {
      // Only compute delay for non-cancelled flights with valid dep time
      if (!Float.isNaN(depTime) && depTime > 0) {
        float sched  = hhmm(crsTime);
        float actual = hhmm(depTime);
        float delay  = actual - sched;

        // Fix overnight wrap (e.g. scheduled 11:50pm, left 12:05am)
        if (delay < -200) delay += 1440;

        totalDelay.set(idx, totalDelay.get(idx) + delay);
        flightCount.set(idx, flightCount.get(idx) + 1);
      }
    }
  }

  // --- Step 2: build per-airport average delay and cancel rate arrays ---
  int n = codes.size();
  float[] avgDelay    = new float[n];
  float[] cancelRate  = new float[n];
  String[] allCodes   = new String[n];
  String[] allCities  = new String[n];

  for (int i = 0; i < n; i++) {
    allCodes[i]  = codes.get(i);
    allCities[i] = cityNames.get(i);
    avgDelay[i]  = (flightCount.get(i) > 0)
                    ? totalDelay.get(i) / flightCount.get(i)
                    : 0;
    cancelRate[i] = (totalCount.get(i) > 0)
                    ? (float) cancelCount.get(i) / totalCount.get(i) * 100
                    : 0;
  }

  // --- Step 3: sort by avg delay descending, keep top SHOW_ROWS ---
  int[] delayOrder  = sortDescending(avgDelay);
  int[] cancelOrder = sortDescending(cancelRate);

  // Store as global parallel arrays, trimmed to SHOW_ROWS
  // We'll swap between them based on mode
  delayAirports = new String[SHOW_ROWS];
  delayCities   = new String[SHOW_ROWS];
  delayVals     = new float[SHOW_ROWS];
  for (int i = 0; i < SHOW_ROWS; i++) {
    int idx = delayOrder[i];
    delayAirports[i] = allCodes[idx];
    delayCities[i]   = allCities[idx];
    delayVals[i]     = avgDelay[idx];
  }

  cancelAirports = new String[SHOW_ROWS];
  cancelCities   = new String[SHOW_ROWS];
  cancelVals     = new float[SHOW_ROWS];
  for (int i = 0; i < SHOW_ROWS; i++) {
    int idx = cancelOrder[i];
    cancelAirports[i] = allCodes[idx];
    cancelCities[i]   = allCities[idx];
    cancelVals[i]     = cancelRate[idx];
  }
}

// Convert HHMM float (e.g. 830.0) to total minutes (e.g. 510)
float hhmm(float t) {
  int ti = (int) t;
  return (ti / 100) * 60 + (ti % 100);
}

// Returns indices that would sort the array from biggest to smallest
int[] sortDescending(float[] arr) {
  int n = arr.length;
  int[] idx = new int[n];
  for (int i = 0; i < n; i++) idx[i] = i;

  // Simple bubble sort (fine for ~120 airports)
  for (int i = 0; i < n - 1; i++) {
    for (int j = 0; j < n - i - 1; j++) {
      if (arr[idx[j]] < arr[idx[j+1]]) {
        int tmp = idx[j]; idx[j] = idx[j+1]; idx[j+1] = tmp;
      }
    }
  }
  return idx;
}

// --- Globals filled by loadData() ---
String[] delayAirports, cancelAirports;
String[] delayCities,   cancelCities;
float[]  delayVals,     cancelVals;

// -------------------------------------------------------

void draw() {
  background(30);

  String[] airports = mode.equals("delay") ? delayAirports : cancelAirports;
  String[] cities   = mode.equals("delay") ? delayCities   : cancelCities;
  float[]  vals     = mode.equals("delay") ? delayVals      : cancelVals;
  float    maxVal   = vals[0];
  color    barColor = mode.equals("delay") ? color(226, 75, 74) : color(239, 159, 39);
  String   title    = mode.equals("delay") ? "Most delayed airports" : "Most cancelled airports";
  String   sub      = mode.equals("delay") ? "Avg departure delay (minutes)" : "Cancellation rate (%)";
  String   unit     = mode.equals("delay") ? " min" : "%";

  // Title
  fill(255);
  textSize(17);
  textAlign(LEFT);
  text(title, 20, 34);

  fill(136);
  textSize(12);
  text(sub, 20, 54);

  stroke(60);
  strokeWeight(0.5);
  line(20, 66, width - 20, 66);
  noStroke();

  // Instructions
  fill(90);
  textSize(11);
  text("press D = delays   C = cancelled", 20, 410);

  // Rows
  int BAR_X     = 230;
  int BAR_MAX_W = 290;

  for (int i = 0; i < SHOW_ROWS; i++) {
    int     y         = 80 + i * 32;
    boolean isHovered = (i == hoveredRow);

    if (isHovered) {
      fill(45);
      noStroke();
      rect(8, y - 2, width - 16, 27, 4);
    }

    if (i < 3) fill(239, 159, 39);
    else        fill(100);
    textSize(12);
    textAlign(RIGHT);
    text(i + 1, 28, y + 16);

    fill(255);
    textSize(13);
    textAlign(LEFT);
    text(airports[i], 36, y + 16);

    fill(136);
    textSize(11);
    text(cities[i], 80, y + 16);

    float bw = (vals[i] / maxVal) * BAR_MAX_W;
    fill(red(barColor), green(barColor), blue(barColor), isHovered ? 255 : 180);
    noStroke();
    rect(BAR_X, y + 3, bw, 16, 3);

    fill(isHovered ? 255 : 170);
    textSize(12);
    textAlign(LEFT);
    text(nf(vals[i], 0, 1) + unit, BAR_X + bw + 6, y + 16);
  }
}

void mouseMoved() {
  hoveredRow = -1;
  for (int i = 0; i < SHOW_ROWS; i++) {
    int y = 80 + i * 32;
    if (mouseY >= y - 2 && mouseY <= y + 25) {
      hoveredRow = i;
      break;
    }
  }
}

void mouseExited() {
  hoveredRow = -1;
}

void keyPressed() {
  if (key == 'd' || key == 'D') mode = "delay";
  if (key == 'c' || key == 'C') mode = "cancelled";
}
